Installation guide:

Navigate to
Cities Skylines II\Cities2_Data\StreamingAssets\Data~
Then replace en-US.loc with the new en-US.loc file
Restart the game.

Asennusohjeet:
Etsi seuraava asennuspolku
Cities Skylines II\Cities2_Data\StreamingAssets\Data~
Korvaa en-US.loc mukana tulevalla en-US.loc tiedostolla
Käynnistä peli uudelleen.
